package ProductManager;

import java.util.Scanner;
import Entity.Product;
import Service.ProductService;
import Service.ProductServiceImpl;


	public class ProductManager {
		
		static Product product = null;
		
		static ProductService service = new ProductServiceImpl();//tightly coupled

		public static void main(String[] args) {
			int pid;
			String pname ;
			float Price;
			String cat;
			
			Scanner scanner = new Scanner(System.in);
			while (true) {
				System.out.println("Product Manager");
				System.out.println("***********************");
				System.out.println("Choose One Option");
				System.out.println("1.Add Product \n2.Get Product Using Id \n3.Update Product  \n4.Delete Product Using Id");
				int option = scanner.nextInt();
				
				switch (option) {
				case 1:
					
					System.out.println("Enter  Product Name");
					 pname = scanner.next();
					System.out.println("Enter Price of the Product");
					Price = scanner.nextFloat();
					System.out.println("Enter Category Of Product");
					 cat = scanner.next();
					product = new Product( pname, Price, cat);
					pid = service.AddProduct(product);
					System.out.println("Product Created with AccNum :" + pid);
					break;
				case 2:
					System.out.println("Enter id of the Product");
					pid = scanner.nextInt();
					product = service.getProductById(pid);
					System.out.println("Product Details: ");
					System.out.println(product);
					break;
				case 3:
					
					System.out.println("Enter ProductNum which to update");
					pid = scanner.nextInt();
					System.out.println("Enter  Product Name");
					 pname = scanner.next();
					System.out.println("Enter Price of the Product");
					Price = scanner.nextFloat();
					System.out.println("Enter Category Of Product");
					 cat = scanner.next();
					 
					pid = service.updateProduct(pid, pname, Price, cat);
					
					
					System.out.println("The Product with id " + pid+ "is updated");
					break;
				case 4:
					System.out.println("Enter ProductNum which has to deleted");
					pid = scanner.nextInt();
					
					pid =service.deleteById(pid);
					System.out.println("The Product with id  " + pid +"is Deleted");
					break;
				/*  case 5:
					System.out.println("Enter  Your ProductNum");
					int fromAccNo = scanner.nextInt();
					System.out.println("Enter  Receiver ProductNum");
					int toAccNo = scanner.nextInt();
					System.out.println("Enter Amount Transfer");
					int amountToTransfer = scanner.nextInt();
					updatedBalance = service.transferAmount(fromAccNo, toAccNo, amountToTransfer);
					System.out.println("After Fund Transfer Remaining Balance In Your Product:" + updatedBalance);
					break;
				case 6:
					System.out.println("Enter  Your ProductNum");
					 fromAccNo = scanner.nextInt();
					 System.out.println(service.printTransactions(fromAccNo));
					break;
					 */
				default:
					System.out.println("Thank You!!!!");
					scanner.close();
					System.exit(0);
				}
			}
		}
	}


