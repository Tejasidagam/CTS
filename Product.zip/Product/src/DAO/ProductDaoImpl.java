package DAO;

import Entity.Product;
import javax.persistence.EntityManager;





public class ProductDaoImpl implements ProductDao{
	
	EntityManager entityManager = Utility.getEntityManager();

	@Override
	public int addProduct(Product pro) {
		// TODO Auto-generated method stub
		entityManager.persist(pro);
		int pid = pro.getPid();
		return pid;
	}

	@Override
	public Product getProductDetails(int pid) {
		// TODO Auto-generated method stub
		Product pro = entityManager.find(Product.class, pid);
		return pro;
		
	}

	@Override
	public int updateProduct(int pid,String name,float Price, String cat) {
		// TODO Auto-generated method stub
		 Product update=getProductDetails(pid);
		 update.setP_name(name);
		 update.setPrice(Price);
		 update.setCat(cat);
		 entityManager.merge(update);
		 
		 return pid;
		 
		 
		 
	}

	@Override
	public int deleteById(int pid) {
		// TODO Auto-generated method stub
		 Product update=getProductDetails(pid);
		 entityManager.remove(update);
		return 0;
	}

	@Override
	public void commitTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin();
	}

}
