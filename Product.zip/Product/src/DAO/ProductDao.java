package DAO;


import Entity.Product;

public interface ProductDao {
 

	   public abstract int addProduct(Product emp); // persist ,merge,remove

		public abstract Product getProductDetails(int pid);// find

		public abstract int updateProduct(int pid,String name,float Price, String cat);// will return updated balance

		public abstract int deleteById(int pid);
		
		
		public abstract void commitTransaction();// getTransaction().commit()

		public abstract void beginTransaction();// getTransaction().begin()
	}


