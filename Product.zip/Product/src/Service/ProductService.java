package Service;

import Entity.Product;

public interface ProductService {
	
	public abstract int AddProduct(Product prod); // em.persist

	
	public abstract Product getProductById(int pid);
	
	public abstract int updateProduct(int pid,String name,float Price, String cat);
	
	public abstract int deleteById(int pid);
	
	
	


}
