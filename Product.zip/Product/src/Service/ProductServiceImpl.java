package Service;

import Entity.Product;



import DAO.ProductDao;
import DAO.ProductDaoImpl;


public class ProductServiceImpl implements ProductService{
	
	ProductDao dao =new  ProductDaoImpl();
	@Override
	public int AddProduct(Product prod) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		int pid = dao.addProduct(prod);
		dao.commitTransaction();
		return pid;
		
	}


	@Override
	public Product getProductById(int pid) {
		// TODO Auto-generated method stub
		Product product = dao.getProductDetails(pid);
		return product;
	}

	@Override
	public int updateProduct(int pid,String name,float Price, String cat) {
		dao.beginTransaction();
		int pid1=dao.updateProduct( pid, name, Price, cat);
		dao.commitTransaction();
		return pid1;
		// TODO Auto-generated method stub
		
	}
	@Override
	public int deleteById(int pid) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		int pid1=dao.deleteById(pid);
		dao.commitTransaction();
		return pid1;
		
		
	}


}
