package Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "Product_info")
public class Product {
	
		@Column(name = "Product_Id", length = 15)
		@Id
		@GeneratedValue
		private int pid;
		@Column(name = "Product_name", length = 15)
		private String p_name;
		@Column(name = "PRICE", length = 15)
		private float price;
		@Column(name = "P_Category", length = 20)
		private String cat;
		
		
		public Product( String p_name, float price, String cat) {
			super();
			
			this.p_name = p_name;
			this.price = price;
			this.cat = cat;
		}
		public int getPid() {
			return pid;
		}
		public void setPid(int pid) {
			this.pid = pid;
		}
		public String getP_name() {
			return p_name;
		}
		public void setP_name(String p_name) {
			this.p_name = p_name;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		public String getCat() {
			return cat;
		}
		public void setCat(String cat) {
			this.cat = cat;
		}
		

}
